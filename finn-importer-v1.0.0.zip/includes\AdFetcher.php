<?php
namespace FINN;

/**
 * Docs: ./docs/functions/AdFetcher.md
 * SPOT: ./SPOT.md#function-catalog
 */

class AdFetcher {
    private function get(string $url): ?string {
        $response = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => [
                'User-Agent' => get_option('finn_importer_user_agent', 'Mozilla/5.0 (compatible; FINNImporter/0.1)'),
                'Accept' => 'text/html,application/xhtml+xml',
            ],
        ]);
        if (is_wp_error($response)) return null;
        if (wp_remote_retrieve_response_code($response) !== 200) return null;
        return wp_remote_retrieve_body($response);
    }

    private function tryCandidates(string $code): ?array {
        $candidates = [
            "https://www.finn.no/bap/webstore/ad.html?finnkode={$code}",
            "https://www.finn.no/bap/forsale/ad.html?finnkode={$code}",
            "https://www.finn.no/realestate/homes/ad.html?finnkode={$code}",
            "https://www.finn.no/recommerce/forsale/item/{$code}",
        ];
        foreach ($candidates as $url) {
            $html = $this->get($url);
            if ($html) {
                $data = $this->parseAd($html, $url, $code);
                if ($data) return $data;
            }
            usleep(200000);
        }
        return null;
    }

    public function fetchByCode(string $code): ?array {
        return $this->tryCandidates($code);
    }

    private function parseAd(string $html, string $url, string $code): ?array {
        $title = $price = $description = $location = $seller = $lastModified = null;
        $images = [];

        // JSON-LD parsing
        if (preg_match_all('#<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>#is', $html, $blocks)) {
            foreach ($blocks[1] as $json) {
                $json = html_entity_decode($json, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $data = json_decode($json, true);
                if (is_array($data)) {
                    $title = $data['name'] ?? $title;
                    if (isset($data['offers']['price'])) {
                        $price = (int) preg_replace('/\D+/', '', $data['offers']['price']);
                    }
                    if (isset($data['image'])) {
                        if (is_array($data['image'])) {
                            $images = array_merge($images, $data['image']);
                        } elseif (is_string($data['image'])) {
                            $images[] = $data['image'];
                        }
                    }
                    $description = $data['description'] ?? $description;
                }
            }
        }

        // Title extraction - look for specific FINN title structures
        if (!$title) {
            // Try specific FINN title classes
            if (preg_match('#<h1[^>]*class="[^"]*u-t2[^"]*"[^>]*>(.*?)</h1>#is', $html, $match)) {
                $title = trim(strip_tags($match[1]));
            } elseif (preg_match('#<h1[^>]*>(.*?)</h1>#is', $html, $match)) {
                $title = trim(strip_tags($match[1]));
            }
            // Try title tag as fallback
            elseif (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $match)) {
                $title = trim(strip_tags($match[1]));
            }
        }

        // Price extraction - look for specific FINN price structures
        if (!$price) {
            // Try FINN specific price patterns
            if (preg_match('#<span[^>]*class="[^"]*u-t1[^"]*"[^>]*>(\d+(?:\s*\d{3})*)\s*kr</span>#is', $html, $match)) {
                $price = (int) preg_replace('/\s+/', '', $match[1]);
            } elseif (preg_match('#(\d+(?:\s*\d{3})*)\s*kr#i', $html, $match)) {
                $price = (int) preg_replace('/\s+/', '', $match[1]);
            }
        }

        // Description extraction - look for specific FINN description structures
        if (!$description) {
            // Try FINN specific description classes
            if (preg_match('#<div[^>]*class="[^"]*u-content[^"]*"[^>]*>(.*?)</div>#is', $html, $match)) {
                $description = trim(strip_tags($match[1]));
            } elseif (preg_match('#<p[^>]*>(.*?)</p>#is', $html, $match)) {
                $description = trim(strip_tags($match[1]));
            }
        }

        // Location extraction
        if (!$location) {
            if (preg_match('#<span[^>]*class="[^"]*location[^"]*"[^>]*>(.*?)</span>#is', $html, $match)) {
                $location = trim(strip_tags($match[1]));
            }
        }

        // Seller extraction
        if (!$seller) {
            if (preg_match('#<span[^>]*class="[^"]*seller[^"]*"[^>]*>(.*?)</span>#is', $html, $match)) {
                $seller = trim(strip_tags($match[1]));
            }
        }

        // Last modified date extraction
        if (!$lastModified) {
            if (preg_match('#Sist endret\s*:\s*([^<\n]+)#i', $html, $match)) {
                $lastModified = trim($match[1]);
            }
        }

        if (!$title) return null;

        return [
            'ext_source' => 'finn',
            'ext_id' => $code,
            'ext_url' => $url,
            'title' => $title,
            'price' => $price,
            'description' => $description ?: '',
            'images' => array_values(array_unique(array_filter($images))),
            'location' => $location,
            'seller' => $seller,
            'last_modified' => $lastModified,
            'breadcrumbs' => $this->extractBreadcrumbs($html),
        ];
    }

    private function extractBreadcrumbs(string $html): ?string {
        $breadcrumbs = [];

        // Look for breadcrumb elements, often in JSON-LD or specific classes
        if (preg_match_all('#<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>#is', $html, $blocks)) {
            foreach ($blocks[1] as $json) {
                $json = html_entity_decode($json, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $data = json_decode($json, true);
                if (is_array($data) && isset($data['breadcrumb'])) {
                    if (is_array($data['breadcrumb'])) {
                        foreach ($data['breadcrumb'] as $crumb) {
                            if (isset($crumb['name'])) $breadcrumbs[] = $crumb['name'];
                        }
                    }
                }
            }
        }

        // Fallback: look for breadcrumb markup
        if (empty($breadcrumbs)) {
            $dom = new \DOMDocument();
            @$dom->loadHTML($html);
            $xpath = new \DOMXPath($dom);
            foreach ($xpath->query('//nav[contains(@class, "breadcrumb")]//a | //ol[contains(@class, "breadcrumb")]//li//a') as $link) {
                $text = trim($link->textContent);
                if ($text) $breadcrumbs[] = $text;
            }
        }

        // Return only the last breadcrumb as requested
        return !empty($breadcrumbs) ? end($breadcrumbs) : null;
    }
}
