# Changelog

All notable changes to **FINN Importer** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased] - 2025-11-06

### Added
- Initial plugin structure and core functionality
- Settings admin page
- SearchScraper for finnkode extraction
- AdFetcher for ad details retrieval
- Importer for WooCommerce product creation
- Logger for error handling
- SPOT.md and function documentation
- TitleParser for extracting brand, model, year from titles
- CategoryMapper for mapping FINN breadcrumbs to Woo categories
- Custom taxonomies for motorcycle brands, models, and years
- Admin filters for taxonomy-based product listing
- Comprehensive brand and model dictionaries with major motorcycle manufacturers
- Enhanced ad data extraction including location, seller, and improved description parsing
- JSON-based brand and model management system
- BrandManager class for CRUD operations on JSON files
- Admin interface for adding/removing brands and models
- ACTIONPLAN.md for development tracking
- Enhanced price extraction for formatted prices (15 000 kr)
- Last modified date extraction from FINN ads
- Stock management (set to 1 for all imported products)
- Additional FINN metadata storage (location, seller, last modified)
- Breadcrumb extraction now returns only the last breadcrumb as requested
- Individual product publishing from draft to publish status
- Bulk publishing functionality for multiple draft products
- Enhanced admin product list with checkboxes and action buttons
- Demonteringsobjekt management page with inline editing
- Motorcycle parts JSON structure with categorized components
- Modal parts selector with grid layout and icons
- Custom taxonomies for km_stand, tilstand, and parts management
- Tag management functionality for additional categorization
- Full WooCommerce product integration for Demonteringsobjekt
- Fetch functionality to re-sync products with FINN data
- Automatic image gallery downloads and setup from FINN
- Out-of-stock automation when products are no longer available on FINN
- Status column showing publish/draft state and stock status
- Plugin packaging system with versioned ZIP creation
- Windows batch and PowerShell build scripts
- VERSION.txt file for version management
- PACKAGING.md documentation for build system
- .gitignore file for proper version control
- Mermaid diagrams in documentation (architecture, data flow, ERD, component relationships)
- Admin panel documentation links (README, CHANGELOG, SPOT, function docs)
- **Plugin Author Information**: Christer Grevæg, Ekhana AS (ekhana.no)
- **Comprehensive Tooltips**: Helpful tooltips throughout all admin interfaces
- **Enhanced UX**: Intuitive interface with emojis, better visual feedback, and improved usability
- **Visual Status Indicators**: Color-coded status displays and stock indicators
- **Improved Inline Editing**: Modern grid-based edit forms with better field organization
- **Internationalization (i18n)**: Complete Norwegian (nb_NO) and English (en_US) translations with gettext support
- **Translation Infrastructure**: POT template, PO files, and MO compilation system for WordPress i18n
- **Condition Swatches**: Four-level condition system (Perfect, Good, Fair, Poor) with color-coded swatches for individual motorcycle parts
- **Individual Part Conditions**: Each selected motorcycle part can have its own condition level (perfect/good/fair/poor)
- **Condition Legend**: Visual legend in parts modal showing all condition levels with colors and descriptions
- **Condition Mapping System**: Bidirectional mapping between condition keys, labels, colors, and order values
- **Visual Condition Indicators**: Small colored circles displayed next to each part showing its condition level
- **Parts Mapping System**: Comprehensive bidirectional mapping between parts and categories with reverse lookups
- **Multi-language Part Support**: Norwegian and English translations for all motorcycle parts
- **Structured Parts Data**: Organized categorization with metadata for each part category
- **Enhanced Parts Modal**: Improved modal with condition legend and individual part condition assignment
- **Condition Validation**: Must check part before condition selection, single condition per part
- **Data Storage Format**: Parts stored with conditions as "Category|Part:condition" format
- **Product Type Classification**: Automatic detection based on title content ("Demonteringsobjekt" vs parts)
- **Separate Admin Interfaces**: Dedicated managers for demonteringsobjekt (bikes) and deler (parts)
- **Manual Type Switching**: Dropdown to reclassify products between types
- **Custom Product Type Taxonomy**: `mc_product_type` for classification tracking
- **Finn.no Torget Integration**: Plugin specifically designed for Finn.no Torget marketplace
- **Norwegian README**: Complete Norwegian documentation (README-nb.md) with full translations
- **Localized Terminology**: Norwegian motorcycle and e-commerce terminology throughout documentation

### Technical Architecture

```mermaid
graph TB
    subgraph "Data Sources"
        FINN[FINN.no API]
        JSON[JSON Files<br/>brands.json<br/>models.json<br/>parts.json]
    end

    subgraph "Core Components"
        SS[SearchScraper]
        AF[AdFetcher]
        TP[TitleParser]
        CM[CategoryMapper]
        IMP[Importer]
    end

    subgraph "Admin Components"
        SET[Settings]
        BM[BrandManager]
        DM[DemonteringsobjektManager]
    end

    subgraph "Storage"
        WC[WooCommerce<br/>Products]
        META[Post Meta<br/>Taxonomies]
        IMG[Media Library]
    end

    FINN --> SS
    SS --> AF
    AF --> TP
    AF --> CM
    TP --> BM
    BM --> JSON
    AF --> IMP
    CM --> IMP
    IMP --> WC
    IMP --> META
    IMP --> IMG

    SET --> IMP
    DM --> WC
    DM --> AF
```

### Database Schema Changes

```mermaid
erDiagram
    wp_posts {
        ID int PK
        post_title varchar
        post_content text
        post_status varchar "draft|publish"
        post_type varchar "product"
    }

    wp_postmeta ||--o{ wp_posts : "metadata"
    wp_postmeta {
        meta_key varchar
        meta_value text
    }

    wp_term_relationships ||--|| wp_posts : "product_terms"
    wp_term_relationships {
        object_id int FK
        term_taxonomy_id int FK
    }

    wp_term_taxonomy ||--|| wp_terms : "taxonomy_terms"
    wp_term_taxonomy {
        taxonomy varchar "mc_brand|mc_model|mc_year|mc_km_stand|mc_tilstand"
        term_id int FK
    }

    %% Key metadata added
    note for wp_postmeta {
        FINN Importer adds:
        - _ext_source: 'finn'
        - _ext_id: finnkode
        - _ext_url: ad URL
        - _demont_km_stand: mileage
        - _demont_parts: parts list
        - _finn_last_modified: sync date
    }
```

### Component Dependencies

```mermaid
classDiagram
    FINN_Importer ..> SearchScraper : creates
    FINN_Importer ..> AdFetcher : creates
    FINN_Importer ..> TitleParser : creates
    FINN_Importer ..> CategoryMapper : creates
    FINN_Importer ..> Importer : creates
    FINN_Importer ..> BrandManager : creates
    FINN_Importer ..> DemonteringsobjektManager : creates
    FINN_Importer ..> Settings : creates

    AdFetcher ..> TitleParser : uses
    AdFetcher ..> CategoryMapper : uses
    Importer ..> TitleParser : uses
    Importer ..> CategoryMapper : uses
    TitleParser ..> BrandManager : uses
    DemonteringsobjektManager ..> AdFetcher : uses for sync
```

## [1.0.0] - 2025-11-06

### Added
- Complete FINN Importer plugin with full WooCommerce integration
- Demonteringsobjekt management system
- Comprehensive documentation with mermaid diagrams
- Packaging system for easy deployment
- Admin panel documentation access
