<?php
namespace FINN;

/**
 * Docs: ./docs/functions/CategoryMapper.md
 * SPOT: ./SPOT.md#function-catalog
 */

class CategoryMapper {
    private array $mapping = [
        'Motorsykler' => 123, // Replace with actual Woo category IDs
        'MC til salgs' => 124,
        'Demont' => 125,
        // Add more mappings as needed
    ];

    public function map($breadcrumbs): ?int {
        // Handle both array and string inputs for backward compatibility
        if (is_string($breadcrumbs)) {
            $breadcrumb = $breadcrumbs;
        } elseif (is_array($breadcrumbs)) {
            $breadcrumb = end($breadcrumbs); // Get last element
        } else {
            return null;
        }

        if (isset($this->mapping[$breadcrumb])) {
            return $this->mapping[$breadcrumb];
        }
        return null;
    }

    // Method to add mappings dynamically if needed
    public function addMapping(string $finnCategory, int $wooCategoryId): void {
        $this->mapping[$finnCategory] = $wooCategoryId;
    }
}
