<?php
namespace FINN;

/**
 * Docs: ./docs/functions/TitleParser.md
 * SPOT: ./SPOT.md#function-catalog
 */

class TitleParser {
    private BrandManager $brandManager;
    private array $brands;
    private array $models;

    public function __construct() {
        $this->brandManager = new BrandManager();
        $this->brands = $this->brandManager->getBrands();
        $this->models = $this->brandManager->getModels();
    }

    public function parse(string $title): array {
        $title = trim($title);

        // Remove common suffixes
        $title = preg_replace('/\s+Demont.*$/i', '', $title);

        $brand = $this->extractBrand($title);
        $year = $this->extractYear($title);
        $model = $this->extractModel($title, $brand, $year);

        return [
            'brand' => $brand,
            'model' => $model,
            'year' => $year,
        ];
    }

    private function extractBrand(string $title): ?string {
        // First check for exact brand matches
        foreach ($this->brands as $brand) {
            if (stripos($title, $brand) === 0 || preg_match('/\b' . preg_quote($brand, '/') . '\b/i', $title)) {
                return $brand;
            }
        }

        // Check for model matches to identify brand
        foreach ($this->models as $brand => $models) {
            foreach ($models as $model) {
                if (preg_match('/\b' . preg_quote($model, '/') . '\b/i', $title)) {
                    return $brand;
                }
            }
        }

        return null;
    }

    private function extractYear(string $title): ?string {
        // Match 4-digit years
        if (preg_match('/\b(\d{4})\b/', $title, $match)) {
            return $match[1];
        }
        // Match ranges like 2009-10, 2010/11, 2011/2012
        if (preg_match('/\b(\d{4})[\/-](\d{2,4})\b/', $title, $match)) {
            $start = $match[1];
            $end = strlen($match[2]) == 2 ? '20' . $match[2] : $match[2];
            return $start . '-' . $end;
        }
        return null;
    }

    private function extractModel(string $title, ?string $brand, ?string $year): ?string {
        $model = $title;

        // Remove brand
        if ($brand) {
            $model = preg_replace('/\b' . preg_quote($brand, '/') . '\b/i', '', $model);
        }

        // Remove year
        if ($year) {
            $model = preg_replace('/\b' . preg_quote($year, '/') . '\b/', '', $model);
            // For ranges
            $yearParts = explode('-', $year);
            foreach ($yearParts as $part) {
                $model = preg_replace('/\b' . preg_quote($part, '/') . '\b/', '', $model);
            }
        }

        // Clean up extra spaces
        $model = trim(preg_replace('/\s+/', ' ', $model));

        // If brand is known, check against known models
        if ($brand && isset($this->models[$brand])) {
            foreach ($this->models[$brand] as $knownModel) {
                if (stripos($model, $knownModel) !== false) {
                    return $knownModel;
                }
            }
        }

        // Return cleaned model if it's not empty
        return $model ?: null;
    }
}
