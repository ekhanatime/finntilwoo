<?php

namespace FINN;

/**
 * Docs: ./docs/functions/DelerManager.md
 * SPOT: ./SPOT.md#function-catalog
 */

class DelerManager {
    private string $partsFile;

    public function __construct() {
        $this->partsFile = FINN_IMPORTER_PATH . 'data/motorcycle_parts.json';
    }

    public static function renderAdmin(): void {
        $manager = new self();

        // Handle inline edit saves
        if (isset($_POST['save_inline_edit']) && check_admin_referer('deler_inline_edit')) {
            $product_id = (int) $_POST['product_id'];
            if ($product_id && current_user_can('edit_post', $product_id)) {
                $manager->saveInlineEdit($product_id, $_POST);
                echo '<div class="updated"><p>Product updated successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to update product.</p></div>';
            }
        }

        // Handle fetch from FINN
        if (isset($_POST['fetch_from_finn']) && check_admin_referer('deler_fetch_finn')) {
            $product_id = (int) $_POST['product_id'];
            if ($product_id && current_user_can('edit_post', $product_id)) {
                $result = $manager->fetchFromFinn($product_id);
                if ($result === true) {
                    echo '<div class="updated"><p>Product data updated from FINN successfully.</p></div>';
                } elseif ($result === false) {
                    echo '<div class="error"><p>Product no longer found on FINN. Set as out of stock.</p></div>';
                } else {
                    echo '<div class="error"><p>Failed to fetch product data from FINN.</p></div>';
                }
            } else {
                echo '<div class="error"><p>Permission denied or invalid product.</p></div>';
            }
        }

        // Handle product type change
        if (isset($_POST['change_product_type']) && check_admin_referer('deler_change_type')) {
            $product_id = (int) $_POST['product_id'];
            $new_type = sanitize_text_field($_POST['product_type']);
            if ($product_id && current_user_can('edit_post', $product_id)) {
                $manager->changeProductType($product_id, $new_type);
                echo '<div class="updated"><p>Product type updated successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to update product type.</p></div>';
            }
        }

        // Handle tag addition
        if (isset($_POST['add_tag']) && check_admin_referer('deler_add_tag')) {
            $product_id = (int) $_POST['product_id'];
            $tag = sanitize_text_field($_POST['new_tag']);
            if ($product_id && $tag && current_user_can('edit_post', $product_id)) {
                wp_set_post_tags($product_id, $tag, true); // true = append
                echo '<div class="updated"><p>Tag added successfully.</p></div>';
            }
        }

        $manager->renderAdminPage();
    }

    private function renderAdminPage(): void {
        $parts_data = $this->getPartsData();

        ?>
        <div class="wrap">
            <h1>Deler Management</h1>

            <!-- Documentation Links -->
            <div class="notice notice-info inline">
                <p>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'README.md'); ?>" target="_blank" class="button button-small"><?php echo esc_html__('📖 README', 'finn-importer'); ?></a>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'CHANGELOG.md'); ?>" target="_blank" class="button button-small"><?php echo esc_html__('📋 Changelog', 'finn-importer'); ?></a>
                </p>
            </div>

            <p><?php echo esc_html__('Manage individual motorcycle parts imported from FINN.no.', 'finn-importer'); ?></p>

            <?php $this->renderProductsTable(); ?>

            <!-- Parts Modal -->
            <div id="parts-modal" class="parts-modal" style="display: none;">
                <div class="parts-modal-content">
                    <div class="parts-modal-header">
                        <h2><?php echo esc_html__('Select Motorcycle Parts', 'finn-importer'); ?></h2>
                        <span class="parts-modal-close">&times;</span>
                    </div>
                    <div class="parts-modal-body">
                        <?php $this->renderPartsGrid($parts_data); ?>
                    </div>
                    <div class="parts-modal-footer">
                        <button type="button" class="button" id="parts-modal-cancel"><?php echo esc_html__('Cancel', 'finn-importer'); ?></button>
                        <button type="button" class="button button-primary" id="parts-modal-save"><?php echo esc_html__('Save Parts', 'finn-importer'); ?></button>
                    </div>
                </div>
            </div>

            <style>
            .deler-table { width: 100%; border-collapse: collapse; }
            .deler-table th, .deler-table td { padding: 8px; border: 1px solid #ddd; text-align: left; }
            .deler-table th { background: #f8f8f8; }
            .inline-edit { display: none; }
            .inline-edit.active { display: table-row; }
            .edit-btn { cursor: pointer; color: #007cba; text-decoration: underline; }
            .save-btn, .cancel-btn { margin-left: 5px; }

            .parts-modal { position: fixed; z-index: 10000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
            .parts-modal-content { background: white; margin: 5% auto; padding: 0; width: 80%; max-width: 800px; border-radius: 8px; }
            .parts-modal-header { padding: 15px 20px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center; }
            .parts-modal-body { padding: 20px; max-height: 60vh; overflow-y: auto; }
            .parts-modal-footer { padding: 15px 20px; border-top: 1px solid #ddd; text-align: right; }
            .parts-modal-close { cursor: pointer; font-size: 24px; }

            .parts-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
            .parts-category { border: 1px solid #ddd; border-radius: 8px; padding: 15px; }
            .parts-category h4 { margin-top: 0; display: flex; align-items: center; gap: 8px; }
            .parts-category .parts-list { margin-top: 10px; }
            .parts-category .parts-list label { display: block; margin: 3px 0; font-weight: normal; }

            .tags-display { display: flex; flex-wrap: wrap; gap: 5px; }
            .tag { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 12px; }
            .add-tag-form { display: inline-block; margin-left: 10px; }
            .add-tag-form input { width: 100px; }

            .product-type-selector { display: inline-block; margin-left: 10px; }
            .product-type-selector select { width: 120px; }
            </style>

            <script>
            jQuery(document).ready(function($) {
                // Inline edit functionality
                $('.edit-btn').on('click', function() {
                    var row = $(this).closest('tr');
                    var displayRow = row;
                    var editRow = row.next('.inline-edit');

                    displayRow.hide();
                    editRow.show().addClass('active');
                });

                $('.cancel-btn').on('click', function() {
                    var editRow = $(this).closest('.inline-edit');
                    var displayRow = editRow.prev('tr');

                    editRow.hide().removeClass('active');
                    displayRow.show();
                });

                // Parts modal functionality
                var modal = $('#parts-modal');
                var currentPartsInput = null;

                $('.parts-modal-btn').on('click', function() {
                    currentPartsInput = $(this).siblings('.parts-input');
                    var currentParts = currentPartsInput.val().split(',').filter(function(p) { return p.trim(); });

                    // Clear all checkboxes
                    modal.find('input[type="checkbox"]').prop('checked', false);

                    // Check current parts
                    currentParts.forEach(function(part) {
                        modal.find('input[value="' + part.trim() + '"]').prop('checked', true);
                    });

                    modal.show();
                });

                $('.parts-modal-close, #parts-modal-cancel').on('click', function() {
                    modal.hide();
                });

                $('#parts-modal-save').on('click', function() {
                    var selectedParts = [];
                    modal.find('input[type="checkbox"]:checked').each(function() {
                        selectedParts.push($(this).val());
                    });

                    if (currentPartsInput) {
                        currentPartsInput.val(selectedParts.join(', '));
                    }

                    modal.hide();
                });

                // Close modal on outside click
                $(window).on('click', function(e) {
                    if ($(e.target).is(modal)) {
                        modal.hide();
                    }
                });
            });
            </script>
        </div>
        <?php
    }

    private function renderProductsTable(): void {
        // Get products that are individual parts (not demonteringsobjekt)
        $args = [
            'post_type' => 'product',
            'post_status' => ['publish', 'draft', 'pending'],
            'posts_per_page' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
            'tax_query' => [
                [
                    'taxonomy' => 'mc_product_type',
                    'field' => 'slug',
                    'terms' => 'part',
                    'operator' => 'IN'
                ]
            ]
        ];

        $query = new \WP_Query($args);

        if ($query->have_posts()) {
            echo '<table class="deler-table">';
            echo '<thead><tr>';
            echo '<th title="' . esc_attr__('Product title and link to WooCommerce editor', 'finn-importer') . '">' . esc_html__('Title', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Unique FINN kode used as product SKU', 'finn-importer') . '">' . esc_html__('FINN Code', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Date when product was imported', 'finn-importer') . '">' . esc_html__('Added', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Current stock status', 'finn-importer') . '">' . esc_html__('Stock', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Product type selector', 'finn-importer') . '">' . esc_html__('Type', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Available actions for individual products', 'finn-importer') . '">' . esc_html__('Actions', 'finn-importer') . '</th>';
            echo '</tr></thead><tbody>';

            while ($query->have_posts()) {
                $query->the_post();
                $product_id = get_the_ID();
                $this->renderProductRow($product_id);
            }

            echo '</tbody></table>';
        } else {
            echo '<p>' . esc_html__('No individual parts found. Import some products first or check product type classification.', 'finn-importer') . '</p>';
        }
        wp_reset_postdata();
    }

    private function renderProductRow(int $product_id): void {
        $finn_code = get_post_meta($product_id, '_ext_id', true);
        $stock_status = get_post_meta($product_id, '_stock_status', true);
        $product_type_terms = wp_get_object_terms($product_id, 'mc_product_type', ['fields' => 'slugs']);

        // Display row
        echo '<tr>';
        echo '<td><a href="' . get_edit_post_link($product_id) . '" title="' . esc_attr__('Edit this product in WooCommerce', 'finn-importer') . '">' . get_the_title($product_id) . '</a></td>';
        echo '<td>' . esc_html($finn_code) . '</td>';
        echo '<td>' . get_the_date() . '</td>';
        echo '<td>';
        if ($stock_status === 'outofstock') {
            echo '<span style="color: #dc3232;" title="' . esc_attr__('This product is out of stock', 'finn-importer') . '">' . esc_html__('🚫 Out of Stock', 'finn-importer') . '</span>';
        } elseif ($stock_status === 'instock') {
            echo '<span style="color: #46b450;" title="' . esc_attr__('This product is in stock', 'finn-importer') . '">' . esc_html__('✅ In Stock', 'finn-importer') . '</span>';
        } else {
            echo '<span style="color: #666;">' . esc_html__('Unknown', 'finn-importer') . '</span>';
        }
        echo '</td>';
        echo '<td>';
        echo '<form method="post" class="product-type-selector">';
        wp_nonce_field('deler_change_type');
        echo '<input type="hidden" name="product_id" value="' . $product_id . '">';
        echo '<select name="product_type" onchange="this.form.submit()">';
        echo '<option value="part" ' . (in_array('part', $product_type_terms) ? 'selected' : '') . '>' . esc_html__('Part', 'finn-importer') . '</option>';
        echo '<option value="demonteringsobjekt" ' . (in_array('demonteringsobjekt', $product_type_terms) ? 'selected' : '') . '>' . esc_html__('Demonteringsobjekt', 'finn-importer') . '</option>';
        echo '</select>';
        echo '<input type="hidden" name="change_product_type" value="1">';
        echo '</form>';
        echo '</td>';
        echo '<td>';
        if ($finn_code) {
            echo '<form method="post" style="display: inline; margin-right: 5px;" title="' . esc_attr__('Re-sync this product with current FINN.no data', 'finn-importer') . '">';
            wp_nonce_field('deler_fetch_finn');
            echo '<input type="hidden" name="product_id" value="' . $product_id . '">';
            echo '<button type="submit" name="fetch_from_finn" class="button button-small">' . esc_html__('🔄 Fetch', 'finn-importer') . '</button>';
            echo '</form>';
        }
        echo '<span class="edit-btn" title="' . esc_attr__('Edit part details inline', 'finn-importer') . '" style="cursor: pointer; color: #007cba;">' . esc_html__('✏️ Edit', 'finn-importer') . '</span>';
        echo '</td>';
        echo '</tr>';

        // Edit row (simplified for parts)
        echo '<tr class="inline-edit">';
        echo '<td colspan="6">';
        echo '<div style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin: 10px 0;">';
        echo '<h4 style="margin-top: 0; color: #007cba;">' . esc_html__('Edit Part Details', 'finn-importer') . '</h4>';
        echo '<form method="post">';
        wp_nonce_field('deler_inline_edit');
        echo '<input type="hidden" name="product_id" value="' . $product_id . '">';
        echo '<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">';

        echo '<div>';
        echo '<label style="font-weight: bold;">' . esc_html__('Title', 'finn-importer') . '</label>';
        echo '<input type="text" name="post_title" value="' . esc_attr(get_the_title($product_id)) . '" style="width: 100%; margin-top: 5px;" title="' . esc_attr__('Update the product title', 'finn-importer') . '">';
        echo '</div>';

        echo '<div>';
        echo '<label style="font-weight: bold;">' . esc_html__('Price', 'finn-importer') . '</label>';
        echo '<input type="number" step="0.01" name="regular_price" value="' . esc_attr(get_post_meta($product_id, '_regular_price', true)) . '" style="width: 100%; margin-top: 5px;" placeholder="1500.00" title="' . esc_attr__('Set the selling price', 'finn-importer') . '">';
        echo '</div>';

        echo '</div>';

        echo '<div style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #ddd; text-align: right;">';
        echo '<button type="submit" name="save_inline_edit" class="button button-primary" title="' . esc_attr__('Save all changes to this product', 'finn-importer') . '">' . esc_html__('💾 Save Changes', 'finn-importer') . '</button>';
        echo '<button type="button" class="button cancel-btn" title="' . esc_attr__('Cancel editing and close this form', 'finn-importer') . '" style="margin-left: 10px;">' . esc_html__('❌ Cancel', 'finn-importer') . '</button>';
        echo '</div>';

        echo '</form>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }

    private function changeProductType(int $product_id, string $new_type): void {
        $taxonomy = 'mc_product_type';
        $term_slug = $new_type;

        if (!term_exists($term_slug, $taxonomy)) {
            wp_insert_term(
                $new_type === 'demonteringsobjekt' ? 'Demonteringsobjekt' : 'Part',
                $taxonomy,
                ['slug' => $term_slug]
            );
        }

        wp_set_object_terms($product_id, [$term_slug], $taxonomy, false);
    }

    private function fetchFromFinn(int $product_id): ?bool {
        $finn_kode = get_post_meta($product_id, '_ext_id', true);
        if (!$finn_kode) {
            return null;
        }

        $adFetcher = new \FINN\AdFetcher();
        $ad_data = $adFetcher->fetchByCode($finn_kode);

        if (!$ad_data) {
            update_post_meta($product_id, '_stock_status', 'outofstock');
            update_post_meta($product_id, '_stock', 0);
            return false;
        }

        // Update product data
        $update_data = [
            'ID' => $product_id,
            'post_title' => $ad_data['title'] ?? get_the_title($product_id),
            'post_content' => $ad_data['description'] ?? '',
        ];
        wp_update_post($update_data);

        // Update price and stock
        if (!empty($ad_data['price'])) {
            update_post_meta($product_id, '_regular_price', $ad_data['price']);
            update_post_meta($product_id, '_price', $ad_data['price']);
        }
        update_post_meta($product_id, '_manage_stock', 'yes');
        update_post_meta($product_id, '_stock', 1);
        update_post_meta($product_id, '_stock_status', 'instock');

        // Update metadata
        if (isset($ad_data['last_modified'])) {
            update_post_meta($product_id, '_finn_last_modified', $ad_data['last_modified']);
        }
        if (isset($ad_data['location'])) {
            update_post_meta($product_id, '_finn_location', $ad_data['location']);
        }
        if (isset($ad_data['seller'])) {
            update_post_meta($product_id, '_finn_seller', $ad_data['seller']);
        }

        // Download images
        if (!empty($ad_data['images'])) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            $gallery_ids = [];
            foreach ($ad_data['images'] as $index => $img_url) {
                $attachment_id = media_sideload_image($img_url, $product_id, $ad_data['title'], 'id');
                if (is_wp_error($attachment_id)) continue;
                if ($index === 0) {
                    set_post_thumbnail($product_id, $attachment_id);
                } else {
                    $gallery_ids[] = $attachment_id;
                }
            }
            if (!empty($gallery_ids)) {
                update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
            }
        }

        return true;
    }

    private function saveInlineEdit(int $product_id, array $data): void {
        if (!empty($data['post_title'])) {
            wp_update_post([
                'ID' => $product_id,
                'post_title' => sanitize_text_field($data['post_title'])
            ]);
        }

        if (isset($data['regular_price'])) {
            $price = (float) $data['regular_price'];
            update_post_meta($product_id, '_regular_price', $price);
            update_post_meta($product_id, '_price', $price);
        }
    }

    private function getPartsData(): array {
        if (file_exists($this->partsFile)) {
            $content = file_get_contents($this->partsFile);
            return json_decode($content, true) ?: [];
        }
        return [];
    }

    private function renderPartsGrid(array $parts_data): void {
        $conditions = $parts_data['conditions'] ?? [];

        echo '<div class="parts-conditions-legend" style="margin-bottom: 20px; padding: 10px; background: #f8f9fa; border-radius: 5px;">';
        echo '<h4 style="margin: 0 0 10px 0;">' . esc_html__('Tilstand / Condition', 'finn-importer') . '</h4>';
        echo '<div style="display: flex; gap: 15px; flex-wrap: wrap;">';
        foreach ($conditions as $key => $condition) {
            echo '<div style="display: flex; align-items: center; gap: 5px;" title="' . esc_attr($condition['description']) . '">';
            echo '<div style="width: 20px; height: 20px; border-radius: 50%; background: ' . esc_attr($condition['color']) . '; border: 2px solid #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.2);"></div>';
            echo '<span style="font-size: 12px; font-weight: bold;">' . esc_html($condition['label']) . '</span>';
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';

        echo '<div class="parts-grid">';

        foreach ($parts_data['motorcycle_parts'] as $category_key => $category) {
            echo '<div class="parts-category">';
            echo '<h4><i class="' . esc_attr($category['icon']) . '"></i> ' . esc_html($category['label_nb']) . '</h4>';
            echo '<div class="parts-list">';

            foreach ($category['parts'] as $part) {
                $part_key = $category_key . '|' . $part['nb'];
                echo '<div class="part-item" style="display: flex; align-items: center; gap: 10px; margin: 8px 0; padding: 8px; border-radius: 4px; background: #f8f9fa;">';
                echo '<input type="checkbox" id="part_' . md5($part_key) . '" value="' . esc_attr($part_key) . '" style="margin: 0;">';
                echo '<label for="part_' . md5($part_key) . '" style="flex: 1; margin: 0; cursor: pointer;">' . esc_html($part['nb']) . '</label>';

                // Condition swatches
                echo '<div class="condition-swatches" style="display: flex; gap: 3px;">';
                foreach ($conditions as $cond_key => $condition) {
                    $swatch_id = 'swatch_' . md5($part_key) . '_' . $cond_key;
                    echo '<div class="condition-swatch" data-part="' . esc_attr($part_key) . '" data-condition="' . esc_attr($cond_key) . '" style="width: 16px; height: 16px; border-radius: 50%; background: ' . esc_attr($condition['color']) . '; border: 2px solid #fff; cursor: pointer; box-shadow: 0 1px 2px rgba(0,0,0,0.1);" title="' . esc_attr($condition['label'] . ': ' . $condition['description']) . '"></div>';
                }
                echo '</div>';

                echo '</div>';
            }

            echo '</div>';
            echo '</div>';
        }

        echo '</div>';

        // JavaScript for condition swatch functionality
        ?>
        <script>
        jQuery(document).ready(function($) {
            var selectedConditions = {};

            $('.condition-swatch').on('click', function() {
                var part = $(this).data('part');
                var condition = $(this).data('condition');
                var checkbox = $('#part_' + $.md5(part));

                if (!checkbox.is(':checked')) {
                    alert('<?php echo esc_js(__("Vennligst merk av delen først / Please check the part first", "finn-importer")); ?>');
                    return;
                }

                selectedConditions[part] = condition;

                $(this).closest('.part-item').find('.condition-swatch').css('border', '2px solid #fff');
                $(this).css('border', '2px solid #007cba');

                console.log('Selected condition for ' + part + ': ' + condition);
            });

            $('.parts-category input[type="checkbox"]').on('change', function() {
                var partKey = $(this).val();
                if (!$(this).is(':checked')) {
                    delete selectedConditions[partKey];
                    $(this).closest('.part-item').find('.condition-swatch').css('border', '2px solid #fff');
                }
            });

            $('#parts-modal-save').off('click').on('click', function() {
                var selectedParts = [];
                $('.parts-category input[type="checkbox"]:checked').each(function() {
                    var partKey = $(this).val();
                    var condition = selectedConditions[partKey] || 'good';
                    selectedParts.push(partKey + ':' + condition);
                });

                if (window.currentPartsInput) {
                    window.currentPartsInput.val(selectedParts.join(', '));
                }

                $('#parts-modal').hide();
            });
        });
        </script>
        <?php
    }
}
