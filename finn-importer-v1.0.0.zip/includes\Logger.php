<?php
namespace FINN;

/**
 * Docs: ./docs/functions/Logger.md
 * SPOT: ./SPOT.md#function-catalog
 */

class Logger {
    public function log(string $message, string $level = 'info'): void {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("FINN Importer [{$level}]: {$message}");
        }
        // Could extend to write to a custom log file or database
    }

    public function error(string $message): void {
        $this->log($message, 'error');
    }

    public function info(string $message): void {
        $this->log($message, 'info');
    }
}
