# FINN Importer Plugin — Overview

This plugin integrates WooCommerce with finn.no to automatically import product listings as draft products. It fetches finnkoder from search query URLs, retrieves ad details (title, price, description, images), and creates/updates WooCommerce products using the finnkode as SKU.

**Source Paths:** `finn-importer.php`, `includes/`

**SPOT:** ./SPOT.md#function-catalog

## Overview

The FINN Importer plugin automates the process of importing listings from finn.no into WooCommerce. Key features:

- Configurable search query URL for fetching finnkoder
- Automatic extraction of product details from individual ads
- Image handling with main image and gallery
- Admin interface for configuration and manual runs
- Scheduled imports via WP-Cron
- Uses finnkode as unique SKU to prevent duplicates

**Langs:** en

## Architecture

```mermaid
graph TB
    A[FINN.no Search] --> B[SearchScraper]
    B --> C[FINN Koder List]
    C --> D[AdFetcher]
    D --> E[Product Data]
    E --> F[TitleParser]
    E --> G[CategoryMapper]
    F --> H[Taxonomies]
    G --> I[Woo Categories]
    E --> J[Importer]
    H --> J
    I --> J
    J --> K[WooCommerce Products]

    L[DemonteringsobjektManager] --> K
    M[BrandManager] --> N[JSON Files]
    N --> F

    O[Admin Panel] --> P[Settings]
    O --> Q[Brand Management]
    O --> R[Demonteringsobjekt]
    P --> J
    Q --> N
    R --> K
```

## Data Flow

```mermaid
sequenceDiagram
    participant FINN as finn.no
    participant SS as SearchScraper
    participant AF as AdFetcher
    participant TP as TitleParser
    participant CM as CategoryMapper
    participant IM as Importer
    participant WC as WooCommerce

    FINN->>SS: Search URL
    SS->>SS: Extract finnkoder
    SS->>AF: List of finnkoder
    loop For each finnkode
        AF->>FINN: Fetch ad HTML
        FINN->>AF: HTML + JSON-LD
        AF->>AF: Parse data
        AF->>TP: Title for parsing
        TP->>AF: Brand/Model/Year
        AF->>CM: Breadcrumbs
        CM->>AF: Woo category ID
        AF->>IM: Complete product data
        IM->>WC: Create product
    end
```

## Database Schema (ERD)

```mermaid
erDiagram
    wp_posts ||--o{ wp_postmeta : "has metadata"
    wp_posts ||--o{ wp_term_relationships : "has terms"
    wp_term_relationships ||--|| wp_term_taxonomy : "links to"
    wp_term_taxonomy ||--|| wp_terms : "defines"

    wp_posts {
        bigint ID PK
        varchar post_title
        text post_content
        varchar post_status "publish|draft|pending"
        varchar post_type "product"
        datetime post_date
    }

    wp_postmeta {
        bigint meta_id PK
        bigint post_id FK
        varchar meta_key
        longtext meta_value
    }

    wp_terms {
        bigint term_id PK
        varchar name
        varchar slug
        bigint term_group
    }

    wp_term_taxonomy {
        bigint term_taxonomy_id PK
        bigint term_id FK
        varchar taxonomy "mc_brand|mc_model|mc_year|mc_km_stand|mc_tilstand"
        varchar description
        bigint parent
        bigint count
    }

    wp_term_relationships {
        bigint object_id FK "post_id"
        bigint term_taxonomy_id FK
        int term_order
    }

    %% Key metadata fields
    note for wp_postmeta {
        Key metadata:
        - _ext_source: 'finn'
        - _ext_id: finnkode (SKU)
        - _ext_url: FINN ad URL
        - _regular_price: price
        - _price: current price
        - _stock: stock quantity
        - _stock_status: 'instock|outofstock'
        - _product_image_gallery: image IDs
        - _demont_km_stand: mileage
        - _demont_parts: parts list
        - _finn_last_modified: last sync
        - _finn_location: seller location
        - _finn_seller: seller info
    }
```

## JSON Data Structure

```mermaid
graph TD
    A[motorcycle_parts.json] --> B[conditions]
    A --> C[motorcycle_parts]
    A --> D[condition_mapping]
    A --> E[parts_mapping]

    B --> B1[perfect: {label,color,order}]
    B --> B2[good: {label,color,order}]
    B --> B3[fair: {label,color,order}]
    B --> B4[poor: {label,color,order}]

    D --> D1[by_label: {Perfekt->perfect}]
    D --> D2[by_color: {#28a745->perfect}]
    D --> D3[by_order: {1->perfect}]

    E --> E1[by_category: {Motor_og_drivverk: [...] }]
    E --> E2[by_part: {Motor komplett->Motor_og_drivverk}]
    E --> E3[english_translations: {Motor komplett->Engine complete}]
```

## Condition System for Parts

### Individual Part Condition Assignment

The plugin supports granular condition tracking for each motorcycle part:

#### Condition Levels
- **perfect** (1): Green - "Perfekt" - "Som ny"
- **good** (2): Yellow - "Bra" - "Lett brukt"
- **fair** (3): Orange - "Middels" - "Brukt"
- **poor** (4): Red - "Dårlig" - "Mye brukt/skadet"

#### Interface Workflow
1. **Part Selection**: User checks parts in categorized modal
2. **Condition Assignment**: Clicks condition swatches next to each selected part
3. **Visual Feedback**: Selected conditions highlighted with blue border
4. **Default Condition**: "good" condition assigned if not explicitly selected

#### Data Storage
Parts stored with condition: `"Category|Part Name:condition_key"`

**Parsed Structure:**
```php
[
    'category' => 'Motor_og_drivverk',
    'part' => 'Motor komplett',
    'condition' => 'perfect',
    'condition_data' => [
        'label' => 'Perfekt',
        'color' => '#28a745',
        'description' => 'Som ny'
    ]
]
```

#### Display Format
- **Condition Indicator**: Small colored circle (8px) next to part name
- **Tag Layout**: Badge-style display with background and padding
- **Hover Information**: Tooltip shows full part name + condition description
- **Truncation**: Long part names truncated with ellipsis

### Parts Modal Enhancement

#### Condition Legend
Top section displaying:
- Four condition levels with color swatches
- Norwegian labels and descriptions
- Hover tooltips for detailed information

#### Individual Part Controls
Each part row contains:
- **Checkbox**: For part selection
- **Part Label**: Clickable for selection
- **Condition Swatches**: Four circular color indicators
- **Validation Logic**: Conditions only selectable for checked parts

#### JavaScript Behavior
- **Single Selection**: Only one condition per part (radio behavior)
- **Visual States**: Blue border for selected conditions
- **Error Prevention**: Alert if condition selected without part checked
- **State Management**: Tracks selected conditions per part

### Mapping Utilities

#### Condition Mapping Methods
- `getCondition($key)`: Retrieve condition metadata
- `mapCondition($value, $by)`: Translate between representations
- `getConditions()`: Get all conditions sorted by order

#### Parts Mapping Methods
- `getPartCategory($partName)`: Find category for part
- `getPartsByCategory($categoryKey)`: Get parts in category
- `getPartTranslation($norwegianPart)`: Get English translation
- `parsePartsWithConditions($string)`: Parse stored data
- `formatPartsWithConditions($array)`: Format for storage

### Benefits

#### Inventory Accuracy
- **Granular Tracking**: Individual condition per part
- **Realistic Valuation**: Accurate pricing based on part conditions
- **Quality Assessment**: Visual condition indicators for quick evaluation

#### User Experience
- **Intuitive Interface**: Color-coded condition system
- **Visual Feedback**: Immediate indication of selections
- **Validation Logic**: Prevents invalid state combinations
- **Responsive Design**: Works across different screen sizes

#### Data Integrity
- **Structured Storage**: Consistent format across all operations
- **Backward Compatibility**: Graceful handling of legacy data
- **Error Recovery**: Default conditions for missing data
- **Type Safety**: Validated condition keys and mappings

## Admin Interface Structure

```mermaid
graph LR
    A[FINN Importer Menu] --> B[Settings]
    A --> C[Brand Management]
    A --> D[Demonteringsobjekt]

    B --> B1[Search URL Config]
    B --> B2[Category Mapping]
    B --> B3[Rate Limiting]
    B --> B4[Import History]

    C --> C1[Brands CRUD]
    C --> C2[Models CRUD]
    C --> C3[JSON File Management]

    D --> D1[Product Table]
    D --> D2[Inline Editing]
    D --> D3[Parts Modal]
    D --> D4[FINN Sync]

    D1 --> D5[Title, Km, Condition, Parts, Price, Status, Tags]
    D2 --> D6[Real-time field editing]
    D3 --> D7[Categorized parts selection]
    D4 --> D8[Image gallery updates]
```

## Component Relationships

```mermaid
classDiagram
    class FINN_Importer {
        +init()
        +activation()
        +admin_menu()
    }

    class SearchScraper {
        +fetchFinkoder(url): array
        +getNextPage(): string
    }

    class AdFetcher {
        +fetchByCode(code): array
        +parseAd(html): array
        +extractBreadcrumbs(html): string
    }

    class TitleParser {
        +parseTitle(title): array
        +extractBrand(): string
        +extractModel(): string
        +extractYear(): int
    }

    class CategoryMapper {
        +map(breadcrumb): int
        +addMapping(finn_cat, woo_cat): void
    }

    class Importer {
        +upsert(ad_data): void
        +createProduct(): int
        +setTaxonomies(): void
        +downloadImages(): void
    }

    class BrandManager {
        +renderAdmin(): void
        +addBrand(name): bool
        +removeBrand(name): bool
        +getBrands(): array
        +getModels(): array
    }

    class DemonteringsobjektManager {
        +renderAdmin(): void
        +fetchFromFinn(product_id): bool
        +saveInlineEdit(): void
        +renderPartsGrid(): void
    }

    class Settings {
        +render(): void
        +handle_publish(): void
        +list_imported_products(): void
    }

    FINN_Importer --> SearchScraper
    FINN_Importer --> AdFetcher
    FINN_Importer --> TitleParser
    FINN_Importer --> CategoryMapper
    FINN_Importer --> Importer
    FINN_Importer --> BrandManager
    FINN_Importer --> DemonteringsobjektManager
    FINN_Importer --> Settings

    Importer --> TitleParser
    Importer --> CategoryMapper
    AdFetcher --> TitleParser
    AdFetcher --> CategoryMapper
    TitleParser --> BrandManager
```

## Function Catalog

### Frontend (HTML/JS)
None - Admin-only plugin

### Backend (PHP)

- **Settings**: Admin configuration page for query URL, category, rate limits. `./docs/functions/Settings.md`
- **SearchScraper**: Fetches HTML from search URL and extracts finnkoder. `./docs/functions/SearchScraper.md`
- **AdFetcher**: Retrieves ad details using finnkode, including breadcrumbs. `./docs/functions/AdFetcher.md`
- **Importer**: Creates/updates WooCommerce products as drafts with taxonomies. `./docs/functions/Importer.md`
- **TitleParser**: Parses titles to extract brand, model, year. `./docs/functions/TitleParser.md`
- **CategoryMapper**: Maps FINN breadcrumbs to WooCommerce categories. `./docs/functions/CategoryMapper.md`
- **BrandManager**: Manages brand and model data in JSON files. `./docs/functions/BrandManager.md`
- **DemonteringsobjektManager**: Manages disassembly objects with inline editing. `./docs/functions/DemonteringsobjektManager.md`
- **DelerManager**: Manages individual parts with streamlined editing. `./docs/functions/DelerManager.md`
- **Logger**: Handles logging and metrics. `./docs/functions/Logger.md`

### Database (MySQL)
WooCommerce products table with custom meta and taxonomies:
- `_ext_source`: 'finn' (source identifier)
- `_ext_id`: finnkode (unique SKU)
- `_ext_url`: FINN ad URL
- `_regular_price`: Product price
- `_stock`: Stock quantity
- `_stock_status`: Stock status
- `_product_image_gallery`: Image gallery IDs
- `_demont_km_stand`: Mileage (for demonteringsobjekt)
- `_demont_parts`: Parts list with conditions (for demonteringsobjekt)
- `_finn_last_modified`: Last sync timestamp
- `_finn_location`: Seller location
- `_finn_seller`: Seller information

**Custom Taxonomies:**
- `mc_brand`: Motorcycle brand (hierarchical)
- `mc_model`: Motorcycle model
- `mc_year`: Production year
- `mc_km_stand`: Mileage for disassembly objects
- `mc_tilstand`: Condition (Brukt/Ny)
- `mc_product_type`: Product classification (demonteringsobjekt/part)

### Product Type Classification

Products are automatically classified based on title content:

#### Detection Logic
- **Demonteringsobjekt**: Titles containing "Demonteringsobjekt" → Complete bikes for parts
- **Part (Deler)**: All other titles → Individual motorcycle components

#### Manual Reclassification
- **Admin Interface**: Dropdown selector in Deler Management
- **Type Switching**: Move products between categories as needed
- **Taxonomy Storage**: `mc_product_type` taxonomy tracks classification

#### Separate Admin Interfaces
- **Demonteringsobjekt Manager**: Full-featured editing for complete bikes
  - Parts selection with conditions
  - Mileage tracking
  - Comprehensive metadata
- **Deler Manager**: Streamlined editing for individual parts
  - Type reclassification
  - Simplified editing
  - Stock management
### Infra/Provisioning
WP-Cron for scheduled runs, HTTP requests with rate limiting.

## Localization Support

- **Primary Language**: Norwegian (nb-NO) for motorcycle terminology
- **Fallback**: English (en) labels available
- **Content**: User-facing strings in Norwegian, documentation in English

## Version Control & Packaging

- **Version File**: `VERSION.txt` for semantic versioning
- **Build Scripts**: PowerShell and batch files for Windows packaging
- **Output**: Versioned ZIP files in `build/` directory
- **Git Integration**: Proper `.gitignore` for clean repositories

## Development Workflow

```mermaid
stateDiagram-v2
    [*] --> Development
    Development --> Testing: build-plugin.ps1
    Testing --> Packaging: .\build-plugin.ps1
    Packaging --> Deployment: Upload ZIP to WordPress
    Deployment --> [*]

    Testing --> Development: Fix issues
    Packaging --> Development: Update code
```

## Changelog
See `./CHANGELOG.md`

## Diagrams
