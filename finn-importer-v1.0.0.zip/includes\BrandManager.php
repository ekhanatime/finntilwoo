<?php
namespace FINN;

/**
 * Docs: ./docs/functions/BrandManager.md
 * SPOT: ./SPOT.md#function-catalog
 */

class BrandManager {
    private string $brandsFile;
    private string $modelsFile;

    public function __construct() {
        $this->brandsFile = FINN_IMPORTER_PATH . 'data/brands.json';
        $this->modelsFile = FINN_IMPORTER_PATH . 'data/models.json';
    }

    public function getBrands(): array {
        $data = $this->readJsonFile($this->brandsFile);
        return $data['brands'] ?? [];
    }

    public function getModels(): array {
        return $this->readJsonFile($this->modelsFile);
    }

    public function getModelsForBrand(string $brand): array {
        $models = $this->getModels();
        return $models[$brand] ?? [];
    }

    public function addBrand(string $brand): bool {
        $data = $this->readJsonFile($this->brandsFile);
        if (!in_array($brand, $data['brands'])) {
            $data['brands'][] = $brand;
            return $this->writeJsonFile($this->brandsFile, $data);
        }
        return false; // Brand already exists
    }

    public function removeBrand(string $brand): bool {
        $data = $this->readJsonFile($this->brandsFile);
        $key = array_search($brand, $data['brands']);
        if ($key !== false) {
            unset($data['brands'][$key]);
            $data['brands'] = array_values($data['brands']); // Reindex array
            $this->writeJsonFile($this->brandsFile, $data);

            // Also remove from models
            $modelsData = $this->readJsonFile($this->modelsFile);
            unset($modelsData[$brand]);
            $this->writeJsonFile($this->modelsFile, $modelsData);

            return true;
        }
        return false; // Brand not found
    }

    public function addModel(string $brand, string $model): bool {
        $data = $this->readJsonFile($this->modelsFile);
        if (!isset($data[$brand])) {
            $data[$brand] = [];
        }
        if (!in_array($model, $data[$brand])) {
            $data[$brand][] = $model;
            return $this->writeJsonFile($this->modelsFile, $data);
        }
        return false; // Model already exists
    }

    public function removeModel(string $brand, string $model): bool {
        $data = $this->readJsonFile($this->modelsFile);
        if (isset($data[$brand])) {
            $key = array_search($model, $data[$brand]);
            if ($key !== false) {
                unset($data[$brand][$key]);
                $data[$brand] = array_values($data[$brand]); // Reindex array
                return $this->writeJsonFile($this->modelsFile, $data);
            }
        }
        return false; // Model not found
    }

    public function updateBrand(string $oldBrand, string $newBrand): bool {
        // Update brands.json
        $brandsData = $this->readJsonFile($this->brandsFile);
        $key = array_search($oldBrand, $brandsData['brands']);
        if ($key !== false) {
            $brandsData['brands'][$key] = $newBrand;
            $this->writeJsonFile($this->brandsFile, $brandsData);

            // Update models.json
            $modelsData = $this->readJsonFile($this->modelsFile);
            if (isset($modelsData[$oldBrand])) {
                $modelsData[$newBrand] = $modelsData[$oldBrand];
                unset($modelsData[$oldBrand]);
                $this->writeJsonFile($this->modelsFile, $modelsData);
            }
            return true;
        }
        return false;
    }

    public function updateModel(string $brand, string $oldModel, string $newModel): bool {
        $data = $this->readJsonFile($this->modelsFile);
        if (isset($data[$brand])) {
            $key = array_search($oldModel, $data[$brand]);
            if ($key !== false) {
                $data[$brand][$key] = $newModel;
                return $this->writeJsonFile($this->modelsFile, $data);
            }
        }
        return false;
    }

    private function readJsonFile(string $filePath): array {
        if (!file_exists($filePath)) {
            return [];
        }
        $content = file_get_contents($filePath);
        $data = json_decode($content, true);
        return $data ?: [];
    }

    private function writeJsonFile(string $filePath, array $data): bool {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return file_put_contents($filePath, $json) !== false;
    }

    public static function renderAdmin(): void {
        $brandManager = new self();

        // Handle form submissions
        if (isset($_POST['add_brand']) && check_admin_referer('finn_brand_management')) {
            $brand = sanitize_text_field($_POST['new_brand']);
            if ($brand && $brandManager->addBrand($brand)) {
                echo '<div class="updated"><p>Brand added successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to add brand or brand already exists.</p></div>';
            }
        }

        if (isset($_POST['remove_brand']) && check_admin_referer('finn_brand_management')) {
            $brand = sanitize_text_field($_POST['remove_brand_name']);
            if ($brand && $brandManager->removeBrand($brand)) {
                echo '<div class="updated"><p>Brand removed successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to remove brand.</p></div>';
            }
        }

        if (isset($_POST['add_model']) && check_admin_referer('finn_brand_management')) {
            $brand = sanitize_text_field($_POST['model_brand']);
            $model = sanitize_text_field($_POST['new_model']);
            if ($brand && $model && $brandManager->addModel($brand, $model)) {
                echo '<div class="updated"><p>Model added successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to add model or model already exists.</p></div>';
            }
        }

        if (isset($_POST['remove_model']) && check_admin_referer('finn_brand_management')) {
            $brand = sanitize_text_field($_POST['remove_model_brand']);
            $model = sanitize_text_field($_POST['remove_model_name']);
            if ($brand && $model && $brandManager->removeModel($brand, $model)) {
                echo '<div class="updated"><p>Model removed successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to remove model.</p></div>';
            }
        }

        $brands = $brandManager->getBrands();
        $models = $brandManager->getModels();

        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('FINN Importer - Brand Management', 'finn-importer'); ?></h1>

            <!-- Documentation Links -->
            <div class="notice notice-info inline">
                <p>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'README.md'); ?>" target="_blank" class="button button-small"><?php echo esc_html__('📖 README', 'finn-importer'); ?></a>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'docs/functions/BrandManager.md'); ?>" target="_blank" class="button button-small"><?php echo esc_html__('📋 BrandManager Docs', 'finn-importer'); ?></a>
                </p>
            </div>

            <p><?php echo esc_html__('Manage motorcycle brands and models for title parsing.', 'finn-importer'); ?></p>

            <div style="display: flex; gap: 20px; margin-top: 20px;">
                <!-- Brands Section -->
                <div style="flex: 1;">
                    <h2><?php echo esc_html__('🏷️ Brands', 'finn-importer'); ?></h2>

                    <!-- Add Brand Form -->
                    <h3><?php echo esc_html__('Add New Brand', 'finn-importer'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('finn_brand_management'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label for="new_brand" title="<?php echo esc_attr__('Enter the motorcycle brand name (e.g., Yamaha, Honda, BMW)', 'finn-importer'); ?>"><?php echo esc_html__('Brand Name', 'finn-importer'); ?></label></th>
                                <td>
                                    <input type="text" id="new_brand" name="new_brand" class="regular-text" placeholder="<?php echo esc_attr__('e.g., Yamaha', 'finn-importer'); ?>" required>
                                    <button type="submit" name="add_brand" class="button button-primary" title="<?php echo esc_attr__('Add this brand to the recognition list', 'finn-importer'); ?>"><?php echo esc_html__('➕ Add Brand', 'finn-importer'); ?></button>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <!-- Remove Brand Form -->
                    <h3><?php echo esc_html__('Remove Brand', 'finn-importer'); ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('finn_brand_management'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label for="remove_brand_name" title="<?php echo esc_attr__('Select brand to remove from recognition list', 'finn-importer'); ?>"><?php echo esc_html__('Brand Name', 'finn-importer'); ?></label></th>
                                <td>
                                    <select name="remove_brand_name" required>
                                        <option value=""><?php echo esc_html__('Choose brand to remove', 'finn-importer'); ?></option>
                                        <?php foreach ($brands as $brand): ?>
                                            <option value="<?php echo esc_attr($brand); ?>"><?php echo esc_html($brand); ?> (<?php echo count($models[$brand] ?? []); ?> models)</option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="remove_brand" class="button button-secondary" title="<?php echo esc_attr__('Remove brand and all its associated models', 'finn-importer'); ?>" onclick="return confirm('<?php echo esc_js(__('Are you sure you want to remove this brand and all its models?', 'finn-importer')); ?>')"><?php echo esc_html__('🗑️ Remove Brand', 'finn-importer'); ?></button>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <!-- Current Brands List -->
                    <h3><?php echo esc_html__('Current Brands', 'finn-importer'); ?> (<?php echo count($brands); ?>)</h3>
                    <div style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;" title="<?php echo esc_attr__('List of all recognized motorcycle brands', 'finn-importer'); ?>">
                        <?php if (empty($brands)): ?>
                            <p style="color: #666; font-style: italic;"><?php echo esc_html__('No brands configured yet.', 'finn-importer'); ?></p>
                        <?php else: ?>
                            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                <?php foreach ($brands as $brand): ?>
                                    <span style="background: #007cba; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;" title="<?php echo esc_attr($brand); ?> has <?php echo count($models[$brand] ?? []); ?> models">
                                        <?php echo esc_html($brand); ?> (<?php echo count($models[$brand] ?? []); ?>)
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Models Section -->
                <div style="flex: 1;">
                    <h2>📈 Models</h2>

                    <!-- Add Model Form -->
                    <h3>Add New Model</h3>
                    <form method="post">
                        <?php wp_nonce_field('finn_brand_management'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label for="model_brand" title="Select which brand this model belongs to">Brand</label></th>
                                <td>
                                    <select name="model_brand" id="model_brand" required>
                                        <option value="">Choose brand first</option>
                                        <?php foreach ($brands as $brand): ?>
                                            <option value="<?php echo esc_attr($brand); ?>"><?php echo esc_html($brand); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="new_model" title="Enter the motorcycle model name (e.g., YZF-R1, CBR1000RR)">Model Name</label></th>
                                <td>
                                    <input type="text" id="new_model" name="new_model" class="regular-text" placeholder="e.g., YZF-R1" required>
                                    <button type="submit" name="add_model" class="button button-primary" title="Add this model to the selected brand">➕ Add Model</button>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <!-- Remove Model Form -->
                    <h3>Remove Model</h3>
                    <form method="post">
                        <?php wp_nonce_field('finn_brand_management'); ?>
                        <table class="form-table">
                            <tr>
                                <th><label for="remove_model_brand" title="Select brand to remove model from">Brand</label></th>
                                <td>
                                    <select name="remove_model_brand" id="remove_model_brand" required onchange="updateModelSelect()">
                                        <option value="">Choose brand</option>
                                        <?php foreach ($brands as $brand): ?>
                                            <option value="<?php echo esc_attr($brand); ?>"><?php echo esc_html($brand); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="remove_model_name" title="Select specific model to remove">Model Name</label></th>
                                <td>
                                    <select name="remove_model_name" id="remove_model_name" required>
                                        <option value="">Choose brand first</option>
                                    </select>
                                    <button type="submit" name="remove_model" class="button button-secondary" title="Remove this model from the brand" onclick="return confirm('Are you sure you want to remove this model?')">🗑️ Remove Model</button>
                                </td>
                            </tr>
                        </table>
                    </form>

                    <!-- Models by Brand -->
                    <h3>Models by Brand</h3>
                    <div style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; background: #f9f9f9;" title="All models organized by brand">
                        <?php foreach ($brands as $brand): ?>
                            <h4 style="margin: 15px 0 8px 0; color: #007cba;"><?php echo esc_html($brand); ?> (<?php echo count($models[$brand] ?? []); ?> models)</h4>
                            <?php if (!empty($models[$brand])): ?>
                                <div style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 15px;">
                                    <?php foreach ($models[$brand] as $model): ?>
                                        <span style="background: #46b450; color: white; padding: 2px 6px; border-radius: 3px; font-size: 11px;" title="Model: <?php echo esc_attr($model); ?>">
                                            <?php echo esc_html($model); ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <p style="color: #666; font-style: italic; margin: 5px 0;">No models configured</p>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <script>
            function updateModelSelect() {
                var brand = document.getElementById('remove_model_brand').value;
                var modelSelect = document.getElementById('remove_model_name');
                modelSelect.innerHTML = '<option value="">Loading...</option>';

                // Use AJAX or just populate from PHP data
                var models = <?php echo json_encode($models); ?>;
                var options = '<option value="">Select Model</option>';

                if (models[brand]) {
                    models[brand].forEach(function(model) {
                        options += '<option value="' + model + '">' + model + '</option>';
                    });
                }

                modelSelect.innerHTML = options;
            }
            </script>
        </div>
        <?php
    }
}
