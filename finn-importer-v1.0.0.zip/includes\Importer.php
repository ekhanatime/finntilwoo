<?php
namespace FINN;

/**
 * Docs: ./docs/functions/Importer.md
 * SPOT: ./SPOT.md#function-catalog
 */

class Importer {
    private int $catId;
    private TitleParser $titleParser;
    private CategoryMapper $categoryMapper;

    public function __construct(int $catId) {
        $this->catId = $catId;
        $this->titleParser = new TitleParser();
        $this->categoryMapper = new CategoryMapper();
    }

    private function findExisting(string $extId): int {
        $query = new \WP_Query([
            'post_type' => 'product',
            'post_status' => ['draft', 'publish', 'pending'],
            'meta_query' => [
                ['key' => '_ext_source', 'value' => 'finn'],
                ['key' => '_ext_id', 'value' => $extId],
            ],
            'fields' => 'ids',
            'posts_per_page' => 1,
        ]);
        return $query->posts[0] ?? 0;
    }

    public function upsert(array $ad): void {
        $product_id = $this->findExisting($ad['ext_id']);

        // Parse title for taxonomies
        $parsed = $this->titleParser->parse($ad['title']);
        $brand_term = $parsed['brand'] ? $this->ensureTerm('mc_brand', $parsed['brand']) : null;
        $model_term = $parsed['model'] ? $this->ensureTerm('mc_model', $parsed['model']) : null;
        $year_term = $parsed['year'] ? $this->ensureTerm('mc_year', $parsed['year']) : null;

        // Map breadcrumbs to category
        $mapped_cat = isset($ad['breadcrumbs']) ? $this->categoryMapper->map($ad['breadcrumbs']) : null;
        $final_cat = $mapped_cat ?: $this->catId;

        // Detect product type
        $title = $ad['title'] ?? '';
        $is_demonteringsobjekt = $this->isDemonteringsobjekt($title);

        if ($product_id) {
            $this->updateProduct($product_id, $ad);
        } else {
            $product_id = $this->createProduct($ad);
        }

        // Store metadata
        update_post_meta($product_id, '_ext_source', $ad['ext_source']);
        update_post_meta($product_id, '_ext_id', $ad['ext_id']);
        update_post_meta($product_id, '_ext_url', $ad['ext_url']);

        // Set product type taxonomy
        $this->setProductType($product_id, $is_demonteringsobjekt);

        // Set taxonomies
        if ($brand_term) wp_set_object_terms($product_id, [$brand_term], 'mc_brand', false);
        if ($model_term) wp_set_object_terms($product_id, [$model_term], 'mc_model', false);
        if ($year_term) wp_set_object_terms($product_id, [$year_term], 'mc_year', false);

        // Set WooCommerce category
        if ($final_cat) {
            wp_set_object_terms($product_id, [$final_cat], 'product_cat', false);
        }

        // Price
        if (!empty($ad['price'])) {
            update_post_meta($product_id, '_regular_price', $ad['price']);
            update_post_meta($product_id, '_price', $ad['price']);
        }

        // Set stock to 1 as requested
        update_post_meta($product_id, '_manage_stock', 'yes');
        update_post_meta($product_id, '_stock', 1);
        update_post_meta($product_id, '_stock_status', 'instock');

        // Store additional FINN data
        if (isset($ad['last_modified'])) {
            update_post_meta($product_id, '_finn_last_modified', $ad['last_modified']);
        }
        if (isset($ad['location'])) {
            update_post_meta($product_id, '_finn_location', $ad['location']);
        }
        if (isset($ad['seller'])) {
            update_post_meta($product_id, '_finn_seller', $ad['seller']);
        }

        $this->downloadImages($product_id, $ad);

        Logger::log("Product upserted: {$product_id} (Type: " . ($is_demonteringsobjekt ? 'Demonteringsobjekt' : 'Part') . ")");
    }

    private function isDemonteringsobjekt(string $title): bool {
        return stripos($title, 'Demonteringsobjekt') !== false;
    }

    private function setProductType(int $product_id, bool $is_demonteringsobjekt): void {
        $taxonomy = 'product_type';
        $term_slug = $is_demonteringsobjekt ? 'demonteringsobjekt' : 'simple';

        // For demonteringsobjekt, we might want to use a custom type, but for now we'll use simple
        // and differentiate using our custom taxonomy
        wp_set_object_terms($product_id, [$term_slug], $taxonomy, false);

        // Also set our custom product type taxonomy
        $custom_taxonomy = 'mc_product_type';
        $custom_term = $is_demonteringsobjekt ? 'demonteringsobjekt' : 'part';

        if (!term_exists($custom_term, $custom_taxonomy)) {
            wp_insert_term(
                $is_demonteringsobjekt ? 'Demonteringsobjekt' : 'Part',
                $custom_taxonomy,
                ['slug' => $custom_term]
            );
        }

        wp_set_object_terms($product_id, [$custom_term], $custom_taxonomy, false);
    }

    private function ensureTerm(string $taxonomy, string $term_name): int {
        $term = term_exists($term_name, $taxonomy);
        if (!$term) {
            $term = wp_insert_term($term_name, $taxonomy);
            if (is_wp_error($term)) return 0;
        }
        return is_array($term) ? $term['term_id'] : $term;
    }
}
