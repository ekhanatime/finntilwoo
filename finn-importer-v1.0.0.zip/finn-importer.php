<?php
/**
 * Plugin Name: FINN Importer for WooCommerce
 * Plugin URI: https://ekhana.no/
 * Description: Import motorcycle listings from finn.no into WooCommerce with specialized disassembly object management. Includes brand/model management, inline editing, and FINN synchronization.
 * Version: 1.0.0
 * Author: Christer Grevæg
 * Author URI: https://ekhana.no/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: finn-importer
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 *
 * @package FINN_Importer
 * @author Christer Grevæg <christer@ekhana.no>
 * @since 1.0.0
 */

// Load plugin textdomain for translations
add_action('plugins_loaded', 'finn_importer_load_textdomain');
function finn_importer_load_textdomain() {
    load_plugin_textdomain('finn-importer', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}

define('FINN_IMPORTER_VER', '1.0.0');
define('FINN_IMPORTER_PATH', plugin_dir_path(__FILE__));
define('FINN_IMPORTER_NS', 'finn_importer');

require_once FINN_IMPORTER_PATH . 'includes/Settings.php';
require_once FINN_IMPORTER_PATH . 'includes/SearchScraper.php';
require_once FINN_IMPORTER_PATH . 'includes/AdFetcher.php';
require_once FINN_IMPORTER_PATH . 'includes/Importer.php';
require_once FINN_IMPORTER_PATH . 'includes/TitleParser.php';
require_once FINN_IMPORTER_PATH . 'includes/CategoryMapper.php';
require_once FINN_IMPORTER_PATH . 'includes/BrandManager.php';
require_once FINN_IMPORTER_PATH . 'includes/DemonteringsobjektManager.php';
require_once FINN_IMPORTER_PATH . 'includes/DelerManager.php';
require_once FINN_IMPORTER_PATH . 'includes/Logger.php';

// Activation hook
register_activation_hook(__FILE__, 'finn_importer_activate');
function finn_importer_activate() {
    if (!wp_next_scheduled('finn_importer_run')) {
        wp_schedule_event(time() + 60, 'hourly', 'finn_importer_run');
    }
    // Initialize brand data
    $brandManager = new \FINN\BrandManager();
    $brandManager->initializeDefaultData();
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'finn_importer_deactivate');
function finn_importer_deactivate() {
    $timestamp = wp_next_scheduled('finn_importer_run');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'finn_importer_run');
    }
}

// Admin menu
add_action('admin_menu', 'finn_importer_admin_menu');
function finn_importer_admin_menu() {
    add_menu_page('FINN Importer', 'FINN Importer', 'manage_woocommerce', 'finn-importer', 'finn_importer_admin_page');
    add_submenu_page('finn-importer', 'Settings', 'Settings', 'manage_woocommerce', 'finn-importer', 'finn_importer_admin_page');
    add_submenu_page('finn-importer', 'Brand Management', 'Brand Management', 'manage_woocommerce', 'finn-importer-brands', 'finn_importer_brands_page');
    add_submenu_page('finn-importer', 'Demonteringsobjekt', 'Demonteringsobjekt', 'manage_woocommerce', 'finn-importer-demont', 'finn_importer_demont_page');
    add_submenu_page('finn-importer', 'Deler', 'Deler', 'manage_woocommerce', 'finn-importer-deler', 'finn_importer_deler_page');
}

function finn_importer_admin_page() {
    \FINN\Settings::render();
}

function finn_importer_brands_page() {
    \FINN\BrandManager::renderAdmin();
}

function finn_importer_demont_page() {
    \FINN\DemonteringsobjektManager::renderAdmin();
}

function finn_importer_deler_page() {
    \FINN\DelerManager::renderAdmin();
}

// Custom meta box for tilstand taxonomy
function mc_tilstand_meta_box($post, $box) {
    $terms = get_terms([
        'taxonomy' => 'mc_tilstand',
        'hide_empty' => false,
    ]);

    // Ensure default terms exist
    if (empty($terms)) {
        wp_insert_term('Brukt', 'mc_tilstand');
        wp_insert_term('Ny', 'mc_tilstand');
        $terms = get_terms([
            'taxonomy' => 'mc_tilstand',
            'hide_empty' => false,
        ]);
    }

    $current_terms = wp_get_object_terms($post->ID, 'mc_tilstand', ['fields' => 'ids']);
    ?>
    <select name="tax_input[mc_tilstand][]" id="mc_tilstand" class="widefat">
        <option value="">Velg tilstand</option>
        <?php foreach ($terms as $term): ?>
            <option value="<?php echo $term->term_id; ?>" <?php selected(in_array($term->term_id, $current_terms)); ?>>
                <?php echo esc_html($term->name); ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}

// Register taxonomies
add_action('init', 'finn_importer_register_taxonomies');
function finn_importer_register_taxonomies() {
    register_taxonomy('mc_brand', 'product', [
        'label' => 'Motorcycle Brand',
        'hierarchical' => true,
        'public' => false,
        'show_admin_column' => true,
    ]);
    register_taxonomy('mc_model', 'product', [
        'label' => 'Motorcycle Model',
        'hierarchical' => false,
        'public' => false,
        'show_admin_column' => true,
    ]);
    register_taxonomy('mc_year', 'product', [
        'label' => 'Year',
        'hierarchical' => false,
        'public' => false,
        'show_admin_column' => true,
    ]);

    // Demonteringsobjekt taxonomies
    register_taxonomy('mc_km_stand', 'product', [
        'label' => 'Km stand',
        'hierarchical' => false,
        'public' => false,
        'show_admin_column' => false,
    ]);
    register_taxonomy('mc_tilstand', 'product', [
        'label' => 'Tilstand',
        'hierarchical' => false,
        'public' => false,
        'show_admin_column' => false,
        'meta_box_cb' => 'mc_tilstand_meta_box',
    ]);

    // Product type taxonomy
    register_taxonomy('mc_product_type', 'product', [
        'label' => 'Product Type',
        'hierarchical' => false,
        'public' => false,
        'show_admin_column' => true,
    ]);
}

// Admin filters for taxonomies
add_action('restrict_manage_posts', 'finn_importer_add_admin_filters');
function finn_importer_add_admin_filters($post_type) {
    if ($post_type === 'product') {
        wp_dropdown_categories([
            'taxonomy' => 'mc_brand',
            'name' => 'mc_brand',
            'show_option_all' => 'All Brands',
            'hierarchical' => true,
        ]);
        wp_dropdown_categories([
            'taxonomy' => 'mc_model',
            'name' => 'mc_model',
            'show_option_all' => 'All Models',
        ]);
        wp_dropdown_categories([
            'taxonomy' => 'mc_year',
            'name' => 'mc_year',
            'show_option_all' => 'All Years',
        ]);
    }
}

add_filter('parse_query', 'finn_importer_filter_admin_query');
function finn_importer_filter_admin_query($query) {
    global $pagenow;
    if ($pagenow === 'edit.php' && isset($_GET['post_type']) && $_GET['post_type'] === 'product') {
        $taxonomies = ['mc_brand', 'mc_model', 'mc_year'];
        foreach ($taxonomies as $tax) {
            if (!empty($_GET[$tax])) {
                $query->query_vars['tax_query'][] = [
                    'taxonomy' => $tax,
                    'field' => 'id',
                    'terms' => (int) $_GET[$tax],
                ];
            }
        }
    }
}

// Manual run action
add_action('admin_post_finn_importer_run_now', 'finn_importer_run_now');
function finn_importer_run_now() {
    check_admin_referer('finn_importer_run_now');
    do_action('finn_importer_run');
    wp_redirect(admin_url('admin.php?page=finn-importer&ran=1'));
    exit;
}

// Scheduled run
add_action('finn_importer_run', 'finn_importer_run_import');
function finn_importer_run_import() {
    $url = get_option('finn_importer_search_url', '');
    if (!$url) return;

    $max_pages = (int) get_option('finn_importer_max_pages', 1);
    $cat_id = (int) get_option('finn_importer_category_id', 0);
    $rate_ms = (int) get_option('finn_importer_rate_ms', 500);

    $scraper = new \FINN\SearchScraper();
    $fetcher = new \FINN\AdFetcher();
    $importer = new \FINN\Importer($cat_id);
    $logger = new \FINN\Logger();

    $logger->log('Starting FINN import run');

    $seen_codes = [];
    for ($page = 1; $page <= $max_pages; $page++) {
        $page_url = $url . (strpos($url, '?') ? '&' : '?') . 'page=' . $page;
        $html = $scraper->get($page_url);
        if (!$html) break;

        $codes = $scraper->extractFinnkoder($html);
        if (empty($codes)) break;

        foreach ($codes as $code) {
            if (in_array($code, $seen_codes)) continue;
            $seen_codes[] = $code;

            $ad = $fetcher->fetchByCode($code);
            if (!$ad) continue;

            $importer->upsert($ad);
            usleep($rate_ms * 1000);
        }
        usleep($rate_ms * 1000);
    }

    $logger->log('Finished FINN import run');
}
