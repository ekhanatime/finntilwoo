<?php
namespace FINN;

/**
 * Docs: ./docs/functions/SearchScraper.md
 * SPOT: ./SPOT.md#function-catalog
 */

class SearchScraper {
    public function get(string $url): ?string {
        $response = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => [
                'User-Agent' => get_option('finn_importer_user_agent', 'Mozilla/5.0 (compatible; FINNImporter/0.1)'),
                'Accept' => 'text/html,application/xhtml+xml',
            ],
        ]);
        if (is_wp_error($response)) return null;
        if (wp_remote_retrieve_response_code($response) !== 200) return null;
        return wp_remote_retrieve_body($response);
    }

    public function extractFinnkoder(string $html): array {
        $codes = [];

        // Regex for finnkode in URLs
        if (preg_match_all('/finnkode=([0-9]{6,12})/', $html, $matches)) {
            foreach ($matches[1] as $id) {
                $codes[$id] = true;
            }
        }

        // DOM parsing for additional links
        $dom = new \DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new \DOMXPath($dom);
        foreach ($xpath->query('//a[@href]') as $link) {
            $href = $link->getAttribute('href');
            if (preg_match('/finnkode=([0-9]{6,12})/', $href, $match)) {
                $codes[$match[1]] = true;
            }
            // Item URL variant
            if (preg_match('#/item/([0-9]{6,12})(?:\b|/|$)#', $href, $match)) {
                $codes[$match[1]] = true;
            }
        }

        return array_keys($codes);
    }
}
