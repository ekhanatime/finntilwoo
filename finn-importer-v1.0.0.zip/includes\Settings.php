<?php
namespace FINN;

/**
 * Docs: ./docs/functions/Settings.md
 * SPOT: ./SPOT.md#function-catalog
 */

class Settings {
    public static function render() {
        // Handle publish action
        if (isset($_POST['publish_product']) && check_admin_referer('finn_publish_product')) {
            $product_id = (int) $_POST['product_id'];
            if ($product_id && current_user_can('publish_posts')) {
                wp_update_post([
                    'ID' => $product_id,
                    'post_status' => 'publish'
                ]);
                echo '<div class="updated"><p>Product published successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Failed to publish product.</p></div>';
            }
        }

        // Handle bulk publish action
        if (isset($_POST['bulk_publish']) && check_admin_referer('finn_bulk_publish') && isset($_POST['product_ids'])) {
            $count = 0;
            foreach ($_POST['product_ids'] as $product_id) {
                $product_id = (int) $product_id;
                if ($product_id && current_user_can('publish_posts')) {
                    wp_update_post([
                        'ID' => $product_id,
                        'post_status' => 'publish'
                    ]);
                    $count++;
                }
            }
            if ($count > 0) {
                echo '<div class="updated"><p>' . $count . ' product(s) published successfully.</p></div>';
            }
        }

        $url = esc_attr(get_option('finn_importer_search_url', ''));
        $cat_id = (int) get_option('finn_importer_category_id', 0);
        $max_pages = (int) get_option('finn_importer_max_pages', 1);
        $rate_ms = (int) get_option('finn_importer_rate_ms', 500);
        $user_agent = esc_attr(get_option('finn_importer_user_agent', 'Mozilla/5.0 (compatible; FINNImporter/0.1)'));

        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('FINN Importer Settings', 'finn-importer'); ?></h1>

            <!-- Plugin Info Box -->
            <div class="notice notice-info">
                <p><strong><?php echo esc_html__('FINN Importer', 'finn-importer'); ?></strong> - <?php echo esc_html__('Import motorcycle listings from finn.no into WooCommerce', 'finn-importer'); ?></p>
                <p>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'README.md'); ?>" target="_blank" class="button"><?php echo esc_html__('📖 View README', 'finn-importer'); ?></a>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'CHANGELOG.md'); ?>" target="_blank" class="button"><?php echo esc_html__('📋 View Changelog', 'finn-importer'); ?></a>
                    <a href="<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2)) . 'SPOT.md'); ?>" target="_blank" class="button"><?php echo esc_html__('🎯 View SPOT', 'finn-importer'); ?></a>
                </p>
            </div>

            <form method="post" action="options.php">
            <?php wp_nonce_field('finn_importer_save'); ?>
                <table class="form-table">
                    <tr>
                        <th>
                            <label for="search_url"><?php echo esc_html__('Search URL', 'finn-importer'); ?></label>
                            <span class="dashicons dashicons-info-outline" title="<?php echo esc_attr__('URL to FINN.no search results page containing motorcycle listings. Include all filters and parameters.', 'finn-importer'); ?>"></span>
                        </th>
                        <td>
                            <input type="url" id="search_url" name="finn_importer_search_url" value="<?php echo esc_attr(get_option('finn_importer_search_url', '')); ?>" class="regular-text" placeholder="<?php echo esc_attr__('https://www.finn.no/motor/mc/brukt/result.html?filters=...', 'finn-importer'); ?>" required>
                            <p class="description"><?php echo esc_html__('Example: https://www.finn.no/motor/mc/brukt/result.html?filters=...', 'finn-importer'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="category_id"><?php echo esc_html__('WooCommerce Category ID', 'finn-importer'); ?></label>
                            <span class="dashicons dashicons-info-outline" title="<?php echo esc_attr__('ID of the WooCommerce product category where imported motorcycles will be placed. Leave empty to use default category.', 'finn-importer'); ?>"></span>
                        </th>
                        <td>
                            <input type="number" id="category_id" name="finn_importer_category_id" value="<?php echo esc_attr(get_option('finn_importer_category_id', '')); ?>" placeholder="123">
                            <p class="description"><?php echo esc_html__('Find category ID in WooCommerce > Products > Categories (hover over category name)', 'finn-importer'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="max_pages"><?php echo esc_html__('Max Pages to Scrape', 'finn-importer'); ?></label>
                            <span class="dashicons dashicons-info-outline" title="<?php echo esc_attr__('Maximum number of search result pages to process. Higher values import more products but take longer.', 'finn-importer'); ?>"></span>
                        </th>
                        <td>
                            <input type="number" id="max_pages" name="finn_importer_max_pages" value="<?php echo esc_attr(get_option('finn_importer_max_pages', 1)); ?>" min="1" max="10">
                            <p class="description"><?php echo esc_html__('Recommended: 1-3 pages for testing, 5-10 for full imports', 'finn-importer'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="rate_ms"><?php echo esc_html__('Rate Limit (ms)', 'finn-importer'); ?></label>
                            <span class="dashicons dashicons-info-outline" title="<?php echo esc_attr__('Delay between requests to FINN.no to avoid being blocked. Higher values are safer but slower.', 'finn-importer'); ?>"></span>
                        </th>
                        <td>
                            <input type="number" id="rate_ms" name="finn_importer_rate_ms" value="<?php echo esc_attr(get_option('finn_importer_rate_ms', 500)); ?>" min="100" max="5000">
                            <p class="description"><?php echo esc_html__('Recommended: 500-1000ms between requests', 'finn-importer'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <label for="user_agent"><?php echo esc_html__('User Agent', 'finn-importer'); ?></label>
                            <span class="dashicons dashicons-info-outline" title="<?php echo esc_attr__('Browser identification string sent to FINN.no. Helps avoid detection as a bot.', 'finn-importer'); ?>"></span>
                        </th>
                        <td>
                            <input type="text" id="user_agent" name="finn_importer_user_agent" value="<?php echo esc_attr(get_option('finn_importer_user_agent', 'Mozilla/5.0 (compatible; FINNImporter/1.0)')); ?>" class="regular-text">
                            <p class="description"><?php echo esc_html__('Leave default unless you experience blocking issues', 'finn-importer'); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_attr__('Save Settings', 'finn-importer'); ?>">
                    <span class="dashicons dashicons-info-outline" style="margin-left: 5px;" title="<?php echo esc_attr__('Save your configuration before running imports', 'finn-importer'); ?>"></span>
                </p>
            </form>

            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('finn_importer_run_now'); ?>
                <input type="hidden" name="action" value="finn_importer_run_now">
                <p>
                    <button class="button button-primary" title="<?php echo esc_attr__('Imports new motorcycle listings from FINN.no. Products are created as drafts for review.', 'finn-importer'); ?>"><?php echo esc_html__('🚀 Run Import Now', 'finn-importer'); ?></button>
                    <span class="dashicons dashicons-info-outline" style="margin-left: 5px;" title="<?php echo esc_attr__('Imports new motorcycle listings from FINN.no. Products are created as drafts for review.', 'finn-importer'); ?>"></span>
                </p>
            </form>

            <h2><?php echo esc_html__('Imported Products', 'finn-importer'); ?></h2>
            <p class="description"><?php echo esc_html__('Manage products imported from FINN.no. Draft products can be published individually or in bulk.', 'finn-importer'); ?></p>
            <form method="post">
                <?php wp_nonce_field('finn_bulk_publish'); ?>
                <?php self::list_imported_products(); ?>
                <p><button type="submit" name="bulk_publish" class="button button-primary"><?php echo esc_html__('Publish Selected Drafts', 'finn-importer'); ?></button></p>
            </form>
        </div>
        <?php
    }

    private static function list_imported_products() {
        $args = [
            'post_type' => 'product',
            'post_status' => ['draft', 'publish', 'pending'],
            'meta_query' => [
                ['key' => '_ext_source', 'value' => 'finn']
            ],
            'posts_per_page' => 20,
        ];
        $query = new \WP_Query($args);

        if ($query->have_posts()) {
            echo '<table class="widefat">';
            echo '<thead><tr>';
            echo '<th title="' . esc_attr__('Select multiple draft products for bulk publishing', 'finn-importer') . '"><input type="checkbox" id="select_all"> <label for="select_all">' . esc_html__('All', 'finn-importer') . '</label></th>';
            echo '<th title="' . esc_attr__('Product title and link to WooCommerce editor', 'finn-importer') . '">' . esc_html__('Title', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Unique FINN kode used as product SKU', 'finn-importer') . '">' . esc_html__('FINN Code', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Date when product was imported', 'finn-importer') . '">' . esc_html__('Added', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Publication status (Draft/Published) and stock status', 'finn-importer') . '">' . esc_html__('Status', 'finn-importer') . '</th>';
            echo '<th title="' . esc_attr__('Available actions for individual products', 'finn-importer') . '">' . esc_html__('Actions', 'finn-importer') . '</th>';
            echo '</tr></thead><tbody>';
            while ($query->have_posts()) {
                $query->the_post();
                $product_id = get_the_ID();
                $finn_code = get_post_meta($product_id, '_ext_id', true);
                $status = get_post_status();
                $is_draft = ($status === 'draft');

                echo '<tr>';
                echo '<td><input type="checkbox" name="product_ids[]" value="' . $product_id . '" ' . ($is_draft ? '' : 'disabled') . '></td>';
                echo '<td><a href="' . get_edit_post_link() . '">' . get_the_title() . '</a></td>';
                echo '<td>' . esc_html($finn_code) . '</td>';
                echo '<td>' . get_the_date() . '</td>';
                echo '<td>' . $status . '</td>';
                echo '<td>';
                if ($is_draft) {
                    echo '<form method="post" style="display: inline;">';
                    wp_nonce_field('finn_publish_product');
                    echo '<input type="hidden" name="product_id" value="' . $product_id . '">';
                    echo '<button type="submit" name="publish_product" class="button button-small" title="' . esc_attr__('Publish this draft product to make it live in your store', 'finn-importer') . '" onclick="return confirm(\'' . esc_js(__('Are you sure you want to publish this product?', 'finn-importer')) . '\')">' . esc_html__('📤 Publish', 'finn-importer') . '</button>';
                    echo '</form>';
                } else {
                    echo '<span style="color: #46b450;" title="' . esc_attr__('This product is published and live in your store', 'finn-importer') . '">' . esc_html__('✅ Published', 'finn-importer') . '</span>';
                }
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';

            // JavaScript for select all functionality
            echo '<script>
            document.getElementById("select_all").addEventListener("change", function() {
                var checkboxes = document.querySelectorAll("input[name=\'product_ids[]\']:not([disabled])");
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = this.checked;
                }, this);
            });
            </script>';
        } else {
            echo '<p>No imported products yet.</p>';
        }
        wp_reset_postdata();
    }
}
